import{W as n}from"./index-qoz3485W.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
