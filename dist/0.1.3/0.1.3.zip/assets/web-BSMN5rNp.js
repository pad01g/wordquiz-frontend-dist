import{W as n}from"./index-Bjm318i0.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
